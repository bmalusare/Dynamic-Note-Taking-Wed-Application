// script.js
document.addEventListener('DOMContentLoaded', () => {
    const noteInput = document.getElementById('noteInput');
    const saveButton = document.getElementById('saveButton');
    const noteList = document.getElementById('noteList');

    // Load notes from localStorage
    let notes = JSON.parse(localStorage.getItem('notes')) || [];
    renderNotes();

    saveButton.addEventListener('click', () => {
        const noteText = noteInput.value.trim();
        if (noteText !== "") {
            notes.push(noteText);
            localStorage.setItem('notes', JSON.stringify(notes));
            noteInput.value = ''; // Clear input field
            renderNotes();
        }
    });


    function renderNotes() {
        noteList.innerHTML = ''; // Clear existing notes
        notes.forEach((note, index) => {
            const noteDiv = document.createElement('div');
            noteDiv.classList.add('note');
            noteDiv.textContent = note;

             // Add delete button to each note
            const deleteButton = document.createElement('button');
            deleteButton.classList.add('delete-button');
            deleteButton.textContent = 'Delete';
            deleteButton.addEventListener('click', (event) => {
                event.stopPropagation(); // Prevent note click when deleting
                deleteNote(index);
            });
            noteDiv.appendChild(deleteButton);


            noteDiv.addEventListener('click', () => {
                noteInput.value = note; // Populate textarea for editing
                notes.splice(index, 1); //remove from the array so it doesn't duplicate
                localStorage.setItem('notes', JSON.stringify(notes));
                renderNotes();
            });

            noteList.appendChild(noteDiv);
        });
    }

    function deleteNote(index) {
        notes.splice(index, 1);
        localStorage.setItem('notes', JSON.stringify(notes));
        renderNotes();
    }
});